'''
Weiyu Lan, Xirong Li, Jianfeng Dong, Fluency-Guided Cross-Lingual Image Captioning, ACM MM 2017
'''

import sys
import os
import logging

from constant import *
from mxnet_feat_os import get_feat_extractor, extract_feature

logger = logging.getLogger(__file__)
logging.basicConfig(
    format="[%(asctime)s - %(filename)s:line %(lineno)s] %(message)s",
    datefmt='%d %b %H:%M:%S')
logger.setLevel(logging.INFO)

def process(options, collection):
    rootpath = options.rootpath
    oversample = options.oversample
    model_prefix = os.path.join(rootpath, options.model_prefix)
    feat = 'resnet-152_imagenet11k' if model_prefix.find('11k')>0 else 'resnet-152_imagenet1k'
    layer = 'flatten0_output'
    batch_size = 1 # change the batch size will get slightly different feature vectors. So stick to batch size of 1.
    feat_name = 'py%s,%s,os' % (feat,layer) if oversample else 'py%s,%s' % (feat, layer) 
    feat_dir = os.path.join(rootpath, collection, 'FeatureData', feat_name)
    id_file = os.path.join(feat_dir, 'id.txt')
    feat_file = os.path.join(feat_dir, 'id.feature.txt')

    for x in [id_file, feat_file]:
        if os.path.exists(x) and not options.overwrite:
            logger.info('%s exists. skip', x)
            return 0


    id_path_file = os.path.join(rootpath, collection, 'id.imagepath.txt')
    data = map(str.strip, open(id_path_file).readlines())
    img_ids = [x.split()[0] for x in data]
    filenames = [x.split()[1] for x in data]

    fe_mod = get_feat_extractor(model_prefix=model_prefix,gpuid=options.gpu, oversample=oversample)

    if not os.path.exists(feat_dir):
        os.makedirs(feat_dir)

    feat_file = os.path.join(feat_dir, 'id.feature.txt')
    fw = open(feat_file,'w')

    im2path = zip(img_ids, filenames)
    success = 0
    fail = 0

    for i, (imgid,impath) in enumerate(im2path):
        try:
            imid_list, features = extract_feature(fe_mod, 1, [imgid], [impath])
            for name, feat in zip(imid_list, features):
                fw.write('%s %s\n' % (name, ' '.join(['%g'%x for x in feat])))
            success += 1
        except:
            logger.error('failed to process %s', imgpath)
            fail += 1

        if i%1e3 == 0:
            logger.info('%d success, %d fail', success, fail)

    logger.info('%d success, %d fail', success, fail) 
 
    fw.close()


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]

    from optparse import OptionParser
    parser = OptionParser(usage="""usage: %prog [options] collection""")
    parser.add_option("--rootpath", default=ROOT_PATH, type="string", help="rootpath (default: %s)" % ROOT_PATH)
    parser.add_option("--overwrite", default=0, type="int", help="overwrite existing file (default=0)")
    parser.add_option("--model_prefix", default=DEFAULT_MODEL_PREFIX, type="string", help=DEFAULT_MODEL_PREFIX)
    parser.add_option("--gpu", default=0, type="int", help="gpu id (default: 0)")
    parser.add_option("--oversample", default=1, type="int", help="oversample (default: 1)")
  
    (options, args) = parser.parse_args(argv)
    if len(args) < 1:
        parser.print_help()
        return 1
    
    #assert(options.job>=1 and options.numjobs >= options.job)
    
    return process(options, args[0])


if __name__ == '__main__':
    sys.exit(main())

