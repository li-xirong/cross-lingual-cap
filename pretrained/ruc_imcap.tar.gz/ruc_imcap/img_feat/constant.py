import os

ROOT_PATH = os.path.join(os.environ['HOME'], 'VisualSearch')
DEFAULT_MODEL_PREFIX = 'mxnet_models/resnet-152_imagenet11k/resnet-152'
DEFAULT_EPOCH = 0
GPU = 0

