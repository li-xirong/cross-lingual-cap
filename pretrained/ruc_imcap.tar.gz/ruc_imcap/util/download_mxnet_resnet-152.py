'''
Weiyu Lan, Xirong Li, Jianfeng Dong, Fluency-Guided Cross-Lingual Image Captioning, ACM MM 2017
'''

import sys
import os


from data_utils import download

rename = {'imagenet1k':'imagenet', 'imagenet11k': 'imagenet-11k'}
rootpath = os.path.join(os.environ['HOME'], 'VisualSearch')

trainset = sys.argv[1] 
if len(sys.argv)>2:
    rootpath = sys.argv[2]
overwrite = 0

assert(trainset in rename), 'invalid trainset %s' % trainset


if 'imagenet1k' == trainset:
    path = 'http://data.mxnet.io/models/imagenet/resnet/152-layers/'
else:
    path = 'http://data.mxnet.io/models/imagenet-11k/resnet-152/'

dirname = os.path.join(rootpath, 'mxnet_models', 'resnet-152_%s' % trainset)
if not os.path.exists(dirname):
    os.makedirs(dirname)


download(path+'resnet-152-symbol.json', dirname=dirname, overwrite=overwrite)
download(path+'resnet-152-0000.params', dirname=dirname, overwrite=overwrite)



