'''
Weiyu Lan, Xirong Li, Jianfeng Dong, Fluency-Guided Cross-Lingual Image Captioning, ACM MM 2017
'''

import sys
import os


from data_utils import download_and_extract

rootpath = os.path.join(os.environ['HOME'], 'VisualSearch')

if len(sys.argv)>1:
    rootpath = sys.argv[1]
overwrite = 0

model_url = 'http://lixirong.net/data/mm2017/ruc_imcap_v0.tar.gz'

download_and_extract(model_url, dirname=rootpath, overwrite=overwrite)

