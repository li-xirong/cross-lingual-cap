'''
Weiyu Lan, Xirong Li, Jianfeng Dong, Fluency-Guided Cross-Lingual Image Captioning, ACM MM 2017
'''

from __future__ import print_function
import os
import sys
import urllib
import tarfile
import logging

logger = logging.getLogger(__file__)
logging.basicConfig(
    format="[%(asctime)s - %(filename)s:line %(lineno)s] %(message)s",
    datefmt='%d %b %H:%M:%S')
logger.setLevel(logging.INFO)

"""
adapted from https://github.com/tensorflow/models/blob/master/slim/datasets/dataset_utils.py
"""
def download(url, dirname, overwrite=False):
    filename = url.split('/')[-1]
    filepath = os.path.join(dirname, filename)
    if os.path.exists(filepath) and not overwrite:
        logger.info('%s exists. skip', filepath)
        return True
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    def _progress(count, block_size, total_size):
        sys.stdout.write('\r>> Downloading %s %.1f%%' % (
                      filename, float(count * block_size) / float(total_size) * 100.0))
        sys.stdout.flush()
    try:
        filepath, _ = urllib.urlretrieve(url, filepath, _progress)
    except:
        return False

    print()
    statinfo = os.stat(filepath)
    logger.info('Successfully downloaded %s, %g bytes.', filepath, statinfo.st_size)
    return True

def download_and_extract(url, dirname, overwrite=False):
    okay = download(url, dirname, overwrite)
    if okay:
        filename = url.split('/')[-1]
        filepath = os.path.join(dirname, filename)
        tar = tarfile.open(filepath)
        tar.list(verbose=False)
        tar.extractall(dirname)
        tar.close()
    
