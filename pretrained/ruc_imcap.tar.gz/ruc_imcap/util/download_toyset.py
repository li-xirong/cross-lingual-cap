'''
Weiyu Lan, Xirong Li, Jianfeng Dong, Fluency-Guided Cross-Lingual Image Captioning, ACM MM 2017
'''

import sys
import os


from data_utils import download_and_extract

rootpath = os.path.join(os.environ['HOME'], 'VisualSearch')

if len(sys.argv)>1:
    rootpath = sys.argv[1]
overwrite = 0

data_url = 'https://github.com/li-xirong/cross-lingual-cap/raw/master/pretrained/toyset.tar.gz'
download_and_extract(data_url, dirname=rootpath, overwrite=overwrite)

