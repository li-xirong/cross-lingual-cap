gpu_id=0 # set to -1 if gpu is not available
rootpath=$HOME/VisualSearch
cnn_trainset=imagenet1k
#cnn_trainset=imagenet11k
oversample=1

raw_feat_name=pyresnet-152_${cnn_trainset},flatten0_output
if [ "$oversample" == 1 ]; then
    raw_feat_name=${raw_feat_name},os
fi  
vf=${raw_feat_name}l2

train_collection=flickr30kzhbbosontrain
val_collection=flickr30kzhbbosonval
model_name=30k_neuraltalk
fluency_method=sample
lang=1
overwrite=0


if [ "$#" -lt 1 ]; then
    echo "Usage: $0 test_collection [rootpath]"
    exit
fi

test_collection=$1

if [ "$#" -gt 1 ]; then
    rootpath=$2
fi

python util/download_mxnet_resnet-152.py ${cnn_trainset} $rootpath
mxmodel_dir=$rootpath/mxnet_models/resnet-152_${cnn_trainset}

if [ ! -d ${mxmodel_dir} ]; then
    echo "${mxmodel_dir} not found. CNN model not ready"
    exit
fi

python util/download_cap_model.py $rootpath
capmodel_dir=$rootpath/${train_collection}/Models/${fluency_method}/${model_name}/vocab_count_thr_5/$vf/variables

if [ ! -d ${capmodel_dir} ]; then
    echo "${capmodel_dir} not found. Caption model not ready"
    exit
fi

python img_feat/generate_imagepath.py ${test_collection} --overwrite $overwrite --rootpath $rootpath
imglistfile=$rootpath/${test_collection}/id.imagepath.txt

if [ ! -f $imglistfile ]; then
    echo "$imglistfile does not exist"
    exit
fi

python img_feat/extract_deep_feat.py ${test_collection} --model_prefix mxnet_models/resnet-152_${cnn_trainset}/resnet-152 --oversample $oversample --gpu ${gpu_id} --overwrite $overwrite --rootpath $rootpath

feat_dir=$rootpath/${test_collection}/FeatureData/$raw_feat_name
feat_file=$feat_dir/id.feature.txt

if [ -f ${feat_file} ]; then
    python img_feat/txt2bin.py 2048 $feat_file 0 $feat_dir --overwrite 1
    rm $feat_file
fi

if [ ! -d ${feat_dir} ]; then
    echo "$feat_dir does not exist"
    exit
fi

python img_feat/norm_feat.py $feat_dir --overwrite $overwrite

feat_dir=$rootpath/${test_collection}/FeatureData/$vf

if [ ! -d ${feat_dir} ]; then
    echo "$feat_dir does not exist"
    exit
fi

if [ "${gpu_id}" -lt 0 ]; then
    gpu_id=0
fi  

python fluent-cap/test_models.py --train_collection $train_collection --val_collection $val_collection --test_collection $test_collection --model_name $model_name --vf_name $vf --gpu ${gpu_id}  --overwrite $overwrite --top_k 1 --beam_size 5 --length_normalization_factor 0.5  --rootpath $rootpath --gpu_memory_fraction 0.3

